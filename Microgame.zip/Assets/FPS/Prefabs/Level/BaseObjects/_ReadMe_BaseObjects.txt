~~~NOTICE~~~

The BaseObjects folder contains prefabs that were created from objects within the RootObjects folder. 

~~~WARNING~~~

Making any adjustments to objects found in the BaseObjects folder will adjust every instance of that object throughout the FPS project. This includes any permutation that exists as a different prefab in the assets folder and within your scene.

If you want to remodel the BaseObjects prefabs, we recommend duplicating the BaseObjects folder, renaming the assets within it, and making your changes those duplicates.