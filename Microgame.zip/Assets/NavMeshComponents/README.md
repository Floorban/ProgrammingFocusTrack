Version used in this project:

https://github.com/Unity-Technologies/NavMeshComponents/releases/tag/2019.3.0f6_2
